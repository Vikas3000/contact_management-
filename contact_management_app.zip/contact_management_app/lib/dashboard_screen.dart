import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class Contact {
  final String name;
  final String phone;

  Contact({
    required this.name,
    required this.phone,
  });

  Map<String, dynamic> toMap() {
    return {
      'name': name,
      'phone': phone,
    };
  }
}

class ContactList extends StatefulWidget {
  const ContactList({super.key});

  @override
  _ContactListState createState() => _ContactListState();
}

class _ContactListState extends State<ContactList> {
  final FirebaseFirestore _db = FirebaseFirestore.instance;

  @override
  Widget build(BuildContext context) {
    User? user = FirebaseAuth.instance.currentUser;
    CollectionReference contactsRef =
        _db.collection('users').doc(user!.uid).collection('contacts');

    return Scaffold(
      appBar: AppBar(
        title: Center(child: const Text('Contacts')),
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: contactsRef.snapshots(),
        builder: (context, snapshot) {
          if (snapshot.hasError) {
            return Center(
              child: Text('Error: ${snapshot.error}'),
            );
          }

          if (!snapshot.hasData) {
            return const Center(
              child: CircularProgressIndicator(),
            );
          }

          List<QueryDocumentSnapshot> documents = snapshot.data!.docs;
          if (documents.isEmpty) {
            return const Center(
              child: Text('No contacts'),
            );
          }

          return ListView.builder(
            itemCount: documents.length,
            itemBuilder: (context, index) {
              Map<String, dynamic> data =
                  documents[index].data() as Map<String, dynamic>;
              Contact contact = Contact(
                name: data['name'],
                phone: data['phone'],
              );
              return ListTile(
                title: Text(contact.name),
                subtitle: Text(contact.phone),
                onTap: () {
                  _editContact(context, documents[index].id);
                },
              );
            },
          );
        },
      ),
      floatingActionButton: SizedBox(
        height: 64.0,
        width: 200.0,
        child: FloatingActionButton(
          onPressed: () {
            _addContact(context);
          },
          backgroundColor: Colors.orange,
          foregroundColor: Colors.white,
          elevation: 50.0,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10.0),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: const [
              Text('Add Contact'),
              SizedBox(width: 2.0),
              Icon(Icons.add),
            ],
          ),
        ),
      ),
    );
  }

  void _addContact(BuildContext context) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => const ContactPage(),
      ),
    );
  }

  void _editContact(BuildContext context, String contactId) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => ContactPage(contactId: contactId),
      ),
    );
  }
}

class ContactPage extends StatefulWidget {
  final String? contactId;

  const ContactPage({super.key, this.contactId});

  @override
  _ContactPageState createState() => _ContactPageState();
}

class _ContactPageState extends State<ContactPage> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _phoneController = TextEditingController();
  final FirebaseFirestore _db = FirebaseFirestore.instance;

  @override
  void initState() {
    super.initState();

    if (widget.contactId != null) {
      _loadContact(widget.contactId!);
    }
  }

  @override
  void dispose() {
    _nameController.dispose();
    _phoneController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.contactId == null ? 'Add Contact' : 'Edit Contact'),
      ),
      body: Form(
        key: _formKey,
        child: Column(
          children: [
            Container(
              padding: const EdgeInsets.all(25),
              child: Container(
                decoration: BoxDecoration(
                  border: Border.all(
                    color: Colors.grey,
                    width: 1.0,
                    style: BorderStyle.solid,
                  ),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: TextFormField(
                  controller: _nameController,
                  decoration: const InputDecoration(
                    labelText: 'Name',
                    border: InputBorder.none,
                    contentPadding:
                        EdgeInsets.symmetric(horizontal: 16.0, vertical: 12.0),
                  ),
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Please enter a name';
                    }
                    return null;
                  },
                ),
              ),
            ),
            Container(
              padding: const EdgeInsets.all(25),
              child: Container(
                decoration: BoxDecoration(
                  border: Border.all(
                    color: Colors.grey,
                    width: 1.0,
                    style: BorderStyle.solid,
                  ),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: TextFormField(
                  controller: _phoneController,
                  decoration: const InputDecoration(
                    labelText: 'Phone',
                    border: InputBorder.none,
                    contentPadding:
                        EdgeInsets.symmetric(horizontal: 16.0, vertical: 12.0),
                  ),
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Please enter a phone number';
                    }
                    return null;
                  },
                ),
              ),
            ),
            const SizedBox(height: 16),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                ElevatedButton(
                  onPressed: () {
                    _saveContact();
                  },
                  style: ElevatedButton.styleFrom(
                    fixedSize: const Size(150, 50), // set the width and height
                    shape: RoundedRectangleBorder(
                      borderRadius:
                          BorderRadius.circular(10), // set the border radius
                    ),
                  ),
                  child: Text(widget.contactId == null ? 'Add' : 'Save'),
                ),
                if (widget.contactId != null)
                  ElevatedButton(
                    onPressed: () {
                      _deleteContact();
                    },
                    style: ElevatedButton.styleFrom(
                      fixedSize: const Size(150, 50), backgroundColor: Colors.red, // set the width and height
                      shape: RoundedRectangleBorder(
                        borderRadius:
                            BorderRadius.circular(10), // set the border radius
                      ), // set the background color
                    ),
                    child: const Text('Delete'),
                  )
              ],
            )
          ],
        ),
      ),
    );
  }

  void _loadContact(String contactId) async {
    DocumentSnapshot contact =
        await _db.collection('contacts').doc(contactId).get();
    if (contact.exists) {
      Map<String, dynamic> data = contact.data() as Map<String, dynamic>;
      _nameController.text = data['name'];
      _phoneController.text = data['phone'];
    }
  }

  void _saveContact() async {
    if (!_formKey.currentState!.validate()) {
      return;
    }
    User? user = FirebaseAuth.instance.currentUser;
    CollectionReference contactsRef =
        _db.collection('users').doc(user!.uid).collection('contacts');

    if (widget.contactId == null) {
      // add contact
      await contactsRef.add(
        Contact(
          name: _nameController.text,
          phone: _phoneController.text,
        ).toMap(),
      );
    } else {
      // update contact
      await contactsRef.doc(widget.contactId).update(
            Contact(
              name: _nameController.text,
              phone: _phoneController.text,
            ).toMap(),
          );
    }

    Navigator.pop(context);
  }

  void _deleteContact() async {
    User? user = FirebaseAuth.instance.currentUser;
    CollectionReference contactsRef =
        _db.collection('users').doc(user!.uid).collection('contacts');
    await contactsRef.doc(widget.contactId).delete();
    Navigator.pop(context);
  }
}
